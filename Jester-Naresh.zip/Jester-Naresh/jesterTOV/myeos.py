import os
import jax
import jax.numpy as jnp
from jax.scipy.special import factorial
from jaxtyping import Array, Float, Int

from . import utils, tov


##############
### CRUSTS ###
##############

DEFAULT_DIR = os.path.join(os.path.dirname(__file__))
CRUST_DIR = f"{DEFAULT_DIR}/crust"

def load_crust(name: str) -> tuple[Array, Array, Array]:
    """
    Load a crust file from the default directory.

    Args:
        name (str): Name of the crust to load, or a filename if a file outside of jose is supplied.

    Returns:
        tuple[Array, Array, Array]: Number densities [fm^-3], pressures [MeV / fm^-3], and energy densities [MeV / fm^-3] of the crust.
    """
    
    # Get the available crust names
    available_crust_names = [f.split(".")[0] for f in os.listdir(CRUST_DIR) if f.endswith(".npz")]
    
    # If a name is given, but it is not a filename, load the crust from the jose directory
    if not name.endswith(".npz"):
        if name in available_crust_names:
            name = os.path.join(CRUST_DIR, f"{name}.npz")
        else:
            raise ValueError(f"Crust {name} not found in {CRUST_DIR}. Available crusts are {available_crust_names}")
    
    # Once the correct file is identified, load it
    crust = jnp.load(name)
    n, p, e = crust["n"], crust["p"], crust["e"]
    return n, p, e

class Interpolate_EOS_model(object):
    """
    Base class to interpolate EOS data. 
    """
    def __init__(self):
        pass
    
    def interpolate_eos(self,
                        n: Float[Array, "n_points"],
                        p: Float[Array, "n_points"],
                        e: Float[Array, "n_points"]):
        """
        Given n, p and e, interpolate to obtain necessary auxiliary quantities. 

        Args:
            n (Float[Array, n_points]): Number densities. Expected units are n[fm^-3]
            p (Float[Array, n_points]): Pressure values. Expected units are p[MeV / fm^3]
            e (Float[Array, n_points]): Energy densities. Expected units are e[MeV / fm^3]
            
        Returns:
            tuple: Interpolated values of n, p, hs (enthalpy) e, and dloge_dlogps.
        """
        
        # Save the provided data as attributes, make conversions
        ns = jnp.array(n * utils.fm_inv3_to_geometric)
        ps = jnp.array(p * utils.MeV_fm_inv3_to_geometric)
        es = jnp.array(e * utils.MeV_fm_inv3_to_geometric)
        
        hs = utils.cumtrapz(ps / (es + ps), jnp.log(ps)) # enthalpy
        dloge_dlogps = jnp.diff(jnp.log(e)) / jnp.diff(jnp.log(p))
        dloge_dlogps = jnp.concatenate(
            (
                jnp.array(
                    [
                        dloge_dlogps.at[0].get(),
                    ]
                ),
                dloge_dlogps,
            )
        )
        return ns, ps, hs, es, dloge_dlogps
class MetaModel_EOS_model(Interpolate_EOS_model):
    """
    MetaModel_EOS_model is a class to interpolate EOS data with a meta-model.

    Args:
        Interpolate_EOS_model (object): Base class of interpolation EOS data.
    """
    def __init__(self,
        # density parameters
        nsat: Float= 0.16,
        nmin_MM_nsat: Float = 0.5,
        nmax_nsat: Float = 7,
        ndat: Int = 200,
        # crust parameters
        crust_name: str = "DH",
        max_n_crust_nsat: Float = 0.5,
        ndat_spline: Int = 10):
        # Initialize nuclear matter parameters
        # Use NEP_dict to set NM parameters
        # Initialize with default None values
        self.e0 = None
        self.rho0 = None
        self.K0 = None
        self.Q0 = None
        self.Z0 = None
        self.J0 = None
        self.L0 = None
        self.Ksym0 = None
        self.Qsym0 = None
        self.Zsym0 = None
        

        self.nsat = nsat
        self.nmin_MM_nsat = nmin_MM_nsat
        self.nmax_nsat = nmax_nsat
        self.ndat = ndat
        self.max_n_crust_nsat = max_n_crust_nsat
        self.ndat_spline = ndat_spline
        
        
        # Fundamental constants
        self.pi = jnp.pi
        self.pi2 = self.pi ** 2
        self.pi3 = 3 * self.pi2
        self.pi8 = 8 * self.pi2
        self.pi13 = (3 * self.pi ** 2) ** (1.0 / 3.0)
        self.hc = jnp.array(197.3282)  # ħc [MeV·fm]
        self.mn = jnp.array(939.0) / self.hc  # Neutron mass
        self.mp = jnp.array(939.0) / self.hc  # Proton mass
        self.me = jnp.array(0.511) / self.hc  # Electron mass
        self.mm = jnp.array(105.660) / self.hc  # Muon mass
        self.me2 = self.me ** 2
        self.mm2 = self.mm ** 2
        self.zero = jnp.array(1.0e-10)
        self.tol = jnp.array(1.0e-3)
        
        # Load and preprocess the crust
        ns_crust, ps_crust, es_crust = load_crust(crust_name)
        max_n_crust = max_n_crust_nsat * nsat
        mask = ns_crust <= max_n_crust
        self.ns_crust, self.ps_crust, self.es_crust = ns_crust[mask], ps_crust[mask], es_crust[mask]
        
        self.mu_lowest = (es_crust[0] + ps_crust[0]) / ns_crust[0]
        self.cs2_crust = jnp.gradient(ps_crust, es_crust)
        
        # Make sure the metamodel starts above the crust
        self.max_n_crust = ns_crust[-1]
        #self.nsat = self.rho0
        # Create density arrays
        self.nmax = nmax_nsat * self.nsat
        self.ndat = ndat
        self.nmin_MM = self.nmin_MM_nsat * self.nsat
        self.n_metamodel = jnp.linspace(self.nmin_MM, self.nmax, self.ndat, endpoint = False)
        self.ns_spline = jnp.append(self.ns_crust, self.n_metamodel)
        self.n_connection = jnp.linspace(self.max_n_crust + 1e-5, self.nmin_MM, self.ndat_spline, endpoint = False)
        
        


    def mu_fermi(self, k, m):
        return jnp.sqrt(k**2 + m**2)

    def eden_fermi(self, k, m):
        m4 = m**4
        prefactor = m4 * self.hc / (8 * jnp.pi**2)
        x = k / m
        x2 = x**2
        x3 = x**3
        sqrt_1px2 = jnp.sqrt(1 + x2)
        arcsinh_x = jnp.arcsinh(x)
        energy_term = sqrt_1px2 * (2*x3 + x) - arcsinh_x
        return prefactor * energy_term
    

    def compute_beta_eos(self, NEP_dict: dict) -> tuple:
        """Compute beta-equilibrium EOS with crust-core matching.
    
        Args:
            NEP_dict: Dictionary of nuclear empirical parameters
        
        Returns:
            tuple: (ns, ps, hs, es, dloge_dlogps, mu, cs2)
        """
        self.e0 = NEP_dict.get("e0", -16.0)
        self.rho0 = NEP_dict.get("rho0", 0.16)  # can fallback to nsat
        self.K0 = NEP_dict.get("K0", 236.8)
        self.Q0 = NEP_dict.get("Q0", 140.6)
        self.Z0 = NEP_dict.get("Z0", 0.0)
        self.J0 = NEP_dict.get("J0", 30.0)
        self.L0 = NEP_dict.get("L0", 72.3)
        self.Ksym0 = NEP_dict.get("Ksym0", 130.7)
        self.Qsym0 = NEP_dict.get("Qsym0", -156.3)
        self.Zsym0 = NEP_dict.get("Zsym0", 0.0) 

        den = self.n_metamodel

        x = (den - self.rho0) / (3 * self.rho0)
        rho3 = 3 * self.rho0
        snm_tayl4 = self.e0 + (1/2)*self.K0*x**2 + (1/6)*self.Q0*x**3 + (1/24)*self.Z0*x**4
        esym_tayl4 = self.J0 + self.L0*x + (1/2)*self.Ksym0*x**2 + (1/6)*self.Qsym0*x**3 + (1/24)*self.Zsym0*x**4
        d_snm = (self.K0 * x + (1.0/2.0) * self.Q0 * x**2 + (1.0/6.0) * self.Z0 * x**3) / rho3
        d_esym = (self.L0 + self.Ksym0 * x + (1.0/2.0) * self.Qsym0 * x**2 + (1.0/6.0) * self.Zsym0 * x**3) / rho3

        
        rtot = jnp.array(den)
        C2 = jnp.array(esym_tayl4)
        ea = jnp.array(snm_tayl4)
        d_ea = jnp.array(d_snm)
        dC = jnp.array(d_esym)

        def compute_energy_mun(i):
            n = 10000
            xmix = 0.01
            c24 = 4.0 * C2[i] / self.hc

            def lepton_solver(_):
                def body_fun(carry):
                    delta0, _ = carry
                    munp = c24 * delta0
                    ke2 = jnp.maximum(munp**2 - self.me2, 0.0)
                    ke = jnp.sqrt(ke2)
                    w = ke**3 / (3.0 * self.pi2)
                    mue = self.mu_fermi(ke, self.me)
                    mue2 = mue**2

                    km2 = jnp.maximum(mue2 - self.mm2, 0.0)
                    km = jnp.sqrt(km2)
                    z = jnp.where(mue > self.mm, km**3 / (3.0 * self.pi2), 0.0)

                    y = w + z
                    x = rtot[i] - y
                    delta = jnp.maximum((x - y) / (x + y + 1e-12), 0.0)

                    new_delta0 = (1.0 - xmix) * delta0 + xmix * delta
                    return (new_delta0, delta), None

                def cond_fun(carry):
                    delta0, delta = carry
                    return jnp.abs(delta - delta0) > self.tol

                (delta0, delta), _ = jax.lax.scan(
                    lambda carry, _: (body_fun(carry)[0], None),
                    (1.0, 0.0), 
                    None, 
                    length=n
                )
                return delta

            delta = jax.lax.cond(
                c24 <= self.me,
                lambda _: 1.0,
                lambda _: lepton_solver(None),
                operand=None
            )

            ke = jnp.sqrt(jnp.maximum((c24 * delta)**2 - self.me2, 0.0))
            mue = self.mu_fermi(ke, self.me)
            mue2 = mue**2
            km = jnp.sqrt(jnp.maximum(mue2 - self.mm2, 0.0))

            e_snm = ea[i]
            d_esnm = d_ea[i]
            d_esym = dC[i]
            e_sym = C2[i] * delta**2
            x = rtot[i] - (ke**3 / (3.0 * self.pi2) + jnp.where(mue > self.mm, km**3 / (3.0 * self.pi2), 0.0))
            y = rtot[i] - x

            e_nm = e_snm + e_sym + (self.mn * x + self.mp * y) * self.hc / rtot[i]
            eden_e = self.eden_fermi(ke, self.me)
            e_tot = e_nm + eden_e / rtot[i]
            e_tot += jnp.where(mue > self.mm, self.eden_fermi(km, self.mm) / rtot[i], 0.0)
            
            mun = e_nm / self.hc + rtot[i] * (d_esnm + d_esym * delta * delta + 
                                   4.0 * delta * C2[i] * y / (rtot[i]**2)) / self.hc
            mup = e_nm / self.hc + rtot[i] * (d_esnm + d_esym * delta * delta - 
                                   4.0 * delta * C2[i] * x / (rtot[i]**2)) / self.hc

            return mun, e_tot * rtot[i]  # Energy density
        mun_all, energy = jax.vmap(compute_energy_mun)(jnp.arange(len(rtot)))
        pres = mun_all * rtot * self.hc - energy

        p_metamodel=pres
        e_metamodel=energy

        cs2_metamodel = jnp.gradient(p_metamodel, e_metamodel)
        # Spline for speed of sound for the connection region
        cs2_spline = jnp.append(self.cs2_crust, cs2_metamodel)
        cs2_connection = utils.cubic_spline(self.n_connection, self.ns_spline, cs2_spline)
        cs2_connection = jnp.clip(cs2_connection, 1e-5, 1.0)
        
        # Concatenate the arrays
        n = jnp.concatenate([self.ns_crust, self.n_connection, self.n_metamodel])
        cs2 = jnp.concatenate([self.cs2_crust, cs2_connection, cs2_metamodel])
        
        # Make sure the cs2 stays within the physical limits
        cs2 = jnp.clip(cs2, 1e-5, 1.0)
        
        # Compute pressure and energy from chemical potential and initialize the parent class with it
        log_mu = utils.cumtrapz(cs2, jnp.log(n)) + jnp.log(self.mu_lowest)
        mu = jnp.exp(log_mu)
        p = utils.cumtrapz(cs2 * mu, n) + self.ps_crust[0]
        e = mu * n - p
        
        ns, ps, hs, es, dloge_dlogps = self.interpolate_eos(n, p, e)
        
        return ns, ps, hs, es, dloge_dlogps, mu, cs2
        
        
        

 
def construct_family(eos: tuple,
                     ndat: Int=50, 
                     min_nsat=2) -> tuple[Float[Array, "ndat"], Float[Array, "ndat"], Float[Array, "ndat"], Float[Array, "ndat"]]:
    """
    Solve the TOV equations and generate the M, R and Lambda curves for the given EOS.

    Args:
        eos (tuple): Tuple of the EOS data (ns, ps, hs, es).
        ndat (int, optional): Number of datapoints used when constructing the central pressure grid. Defaults to 50.
    Returns:
        tuple[Float[Array, "ndat"], Float[Array, "ndat"], Float[Array, "ndat"], Float[Array, "ndat"]]: log(pcs), masses in solar masses, radii in km, and dimensionless tidal deformabilities
    """
    # Construct the dictionary
    ns, ps, hs, es, dloge_dlogps = eos
    eos_dict = dict(p=ps, h=hs, e=es, dloge_dlogp=dloge_dlogps)
    
    # calculate the pc_min
    pc_min = utils.interp_in_logspace(min_nsat * 0.16 * utils.fm_inv3_to_geometric, ns, ps)

    # end at pc at pmax
    pc_max = eos_dict["p"][-1]

    pcs = jnp.logspace(jnp.log10(pc_min), jnp.log10(pc_max), num=ndat)

    def solve_single_pc(pc):
        """Solve for single pc value"""
        return tov.tov_solver(eos_dict, pc)
    ms, rs, ks = jax.vmap(solve_single_pc)(pcs)
    
    # calculate the compactness
    cs = ms / rs

    # convert the mass to solar mass and the radius to km
    ms /= utils.solar_mass_in_meter
    rs /= 1e3

    # calculate the tidal deformability
    lambdas = 2.0 / 3.0 * ks * jnp.power(cs, -5.0)
    #calculate the energy density from interpolation
    #ecs = utils.interp_in_logspace(pcs, ps, es)
    # Limit masses to be below MTOV
    pcs, ms, rs, lambdas = utils.limit_by_MTOV(pcs, ms, rs, lambdas)
    
    # Get a mass grid and interpolate, since we might have dropped provided some duplicate points
    mass_grid = jnp.linspace(jnp.min(ms), jnp.max(ms), ndat)
    rs = jnp.interp(mass_grid, ms, rs)
    lambdas = jnp.interp(mass_grid, ms, lambdas)
    pcs = jnp.interp(mass_grid, ms, pcs)
    #ecs = jnp.interp(mass_grid, ms, ecs)
    
    ms = mass_grid
    

    return jnp.log(pcs), ms, rs, lambdas

      




    


